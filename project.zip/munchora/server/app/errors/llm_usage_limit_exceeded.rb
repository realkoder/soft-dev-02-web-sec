class LlmUsageLimitExceeded < StandardError; end
