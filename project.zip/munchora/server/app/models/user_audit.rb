class UserAudit < ApplicationRecord
end
