class GroceryListItemAudit < ApplicationRecord
end
