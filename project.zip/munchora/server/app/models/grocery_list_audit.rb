class GroceryListAudit < ApplicationRecord
end
