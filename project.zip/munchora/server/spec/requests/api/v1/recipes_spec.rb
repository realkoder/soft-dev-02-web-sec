require 'rails_helper'

RSpec.describe "Api::v1::Recipes", type: :request do
  describe "GET /index" do
    pending "add some examples (or delete) #{__FILE__}"
  end
end
