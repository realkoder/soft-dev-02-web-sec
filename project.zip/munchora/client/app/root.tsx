import { isRouteErrorResponse, Links, Meta, Outlet, Scripts, ScrollRestoration } from 'react-router';

import type { Route } from './+types/root';
import './app.css';
import { Toaster } from 'sonner';
import { Provider } from 'jotai';
import AuthBootstrapper from './layout/AuthBootstrapper';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

const queryClient = new QueryClient();

export const links: Route.LinksFunction = () => [
  { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
  {
    rel: 'preconnect',
    href: 'https://fonts.gstatic.com',
    crossOrigin: 'anonymous',
  },
  {
    rel: 'stylesheet',
    href: 'https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap',
  },
];

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
    <head>
      <meta charSet="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1"/>
      {/*<meta httpEquiv="Content-Security-Policy"*/}
      {/*      content="default-src 'self';*/}
      {/*         script-src 'self' 'unsafe-inline' 'unsafe-eval' https://fonts.googleapis.com;*/}
      {/*         style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://fonts.gstatic.com;*/}
      {/*         font-src 'self' https://fonts.gstatic.com;*/}
      {/*         img-src 'self' data: blob: https:;*/}
      {/*         connect-src 'self';*/}
      {/*         worker-src 'self' blob:;*/}
      {/*         manifest-src 'self';"/>*/}
      <Meta/>
      <Links/>
      <link rel="icon" href="/favicon.ico"/>
      <link rel="shortcut icon" href="/favicon.ico"/>
    </head>
    <body>
    {children}
    <ScrollRestoration/>
    <Scripts/>
    </body>
    </html>
  );
}

export default function App() {
  return (
    <main>
      <QueryClientProvider client={queryClient}>
        <Provider>
          <Toaster/>
          <AuthBootstrapper/>
          <Outlet/>
        </Provider>
      </QueryClientProvider>
    </main>
  );
}

export function ErrorBoundary({error}: Route.ErrorBoundaryProps) {
  let message = 'Oops!';
  let details = 'An unexpected error occurred.';
  let stack: string | undefined;

  if (isRouteErrorResponse(error)) {
    message = error.status === 404 ? '404' : 'Error';
    details = error.status === 404 ? 'The requested page could not be found.' : error.statusText || details;
  } else if (import.meta.env.DEV && error && error instanceof Error) {
    details = error.message;
    stack = error.stack;
  }

  return (
    <main className="pt-16 p-4 container mx-auto">
      <h1>{message}</h1>
      <p>{details}</p>
      {stack && (
        <pre className="w-full p-4 overflow-x-auto">
          <code>{stack}</code>
        </pre>
      )}
    </main>
  );
}
